<?php class pieceEchec{

    /**
     * données
     * @var int
     */

    private $coordonnees;

    /**
     * données2
     * @var int
     */

    private $coordonnees2;

    /**
     * couleur
     * @var string
     */

    private $couleur1 = 'blanche';
    private $couleur2 = 'noire';



}

?>
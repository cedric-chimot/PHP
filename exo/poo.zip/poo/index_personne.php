<?php
require_once 'classes/personnes.php';

echo "Création de Cedric chez Java";

$p1 = new Personne("Cedric", "Java");
echo '<br/><br/>';
$p1->afficher();
echo '<br/><br/>';

echo "Cedric va chez JAVA -> ";
echo '<br/><br/>';
$p1->setSociete("JAVA");
$p1->afficher();

echo "Le groupe a un effectif de " . Personne::getEffectif() . " Personne(s).";
echo '<br/><br/>';





?>
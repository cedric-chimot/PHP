<?php

include_once 'classes/voiture.php';

echo '<pre>';

$voiture1 = new voiture('Renault', 'Twingo', 'Blanche', 'VFX-253555-15489456', 'VX-288-BQ');
var_dump($voiture1) . '\n';
echo '<br>';
$voiture1->show() . '\n';
echo '<br>';

$voiture2 = new voiture('Porsche', '911', 'Noire', 'XZN-251015-10105245', 'ZR-589-UU');
echo '<br>';
var_dump($voiture2) . '\n';
echo '<br>';
$voiture2->show() . '\n';

echo '</pre>';

?>
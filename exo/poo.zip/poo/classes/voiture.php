<?php

class voiture
{

    public $marque;
    public $modele;
    public $couleur;
    public $vin;
    public $immat;

    public function __construct(string $marque, string $modele, string $couleur, string $vin, string $immat)
    {
        $this->marque = $marque;
        $this->modele = $modele;
        $this->couleur = $couleur;
        $this->vin = $vin;
        $this->immat = $immat;
    }

    public function show()
    {
        echo "La voiture est de marque $this->marque et de modèle $this->modele. Elle est de couleur $this->couleur, à pour code VIN $this->vin et son immatriculation est $this->immat.";
    }
}
